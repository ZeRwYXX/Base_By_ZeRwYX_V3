module.exports = {
    emojis: {
        off: '❗️',
        error: '❌',
        success: '✅',
    },

    discord: {
        token: '', //Token ici
        prefix: '//', //Prefix du bot ici
        inf: "Name bot", //Nom du bot ici
        activity: `activité`, //Activité du bot ici
    },

};